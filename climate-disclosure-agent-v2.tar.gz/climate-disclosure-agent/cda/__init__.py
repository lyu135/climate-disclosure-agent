"""
Climate Disclosure Agent - Main package initialization.
"""
from cda.agent import ClimateDisclosureAgent

__all__ = ['ClimateDisclosureAgent']